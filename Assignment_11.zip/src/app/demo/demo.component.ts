import { Component } from '@angular/core';
import { ArithmaticService } from '../arithmatic.service';


@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css',
  providers : [ArithmaticService],
})
export class DemoComponent 
{
  public Add_result : number = 0;
  public Sub_result : number = 0;

  constructor(private obj : ArithmaticService)
  {
    this.Add_result = this.obj.Addition(10,11);
    this.Sub_result = this.obj.Subtraction(20,10);

  } 

}
