import { Component } from '@angular/core';
import { NumberService } from '../number.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-child1',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './child1.component.html',
  styleUrl: './child1.component.css',
  providers : [NumberService],
})
export class Child1Component 
{
  public flag = false;
  constructor(private obj1:NumberService)
  {
      this.flag = this.obj1.ChkPrime(78);
  }

}
