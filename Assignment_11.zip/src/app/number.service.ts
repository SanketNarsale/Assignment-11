import { Injectable, booleanAttribute } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService {

  constructor() { }

  public ChkPrime(n : number)
  {
    
    var bFlag = true;

    if(n == 2)
      return bFlag;

    for(var i = 2;i<(n/2); i++)
    {
      if((n%i) == 0)
      {
        bFlag = false;
        break;
      }
    }

    return bFlag;

  }
}
