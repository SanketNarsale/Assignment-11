import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArithmaticService {

  constructor() {

   }

   public Addition(a : number, b:number)
   {
         return a+b;
   }

   public Subtraction(a :number, b: number)
   {
        return a-b;
   }
}
